from database.user_database import UserDatabase
from models.usuario import Usuario


class ControllerUsuario:

    # função inicia banco de dados dos usuários para gerenciar as transações.
    # função inicia a classe usuário para uso das regras de negócio.
    def __init__(self):
        self.bd = UserDatabase()
        self.usuario = Usuario()

    # função que adiciona usuários e já insere seus respectivos ID's.
    # essa função é uma auxiliar da função de cadastrar usuário que faz as validações.
    def adcionar_usuario(self):
        self.usuario.id_usuario = int(self.bd.autoincremento())
        self.bd.insert_obj(self.usuario.to_list())

    # função que valida usuários.
    def validar_usuario(self, dado, valor):
        if dado == "nome":
            if self.usuario.nome_valido(valor):
                self.usuario.nome = valor
                return True
        elif dado == "contato":
            if self.usuario.contato_valido(valor):
                self.usuario.contato = valor
                return True
        else:
            return False

    # função que lista todos os usuários.
    def listar_todos_os_usuarios(self):
        return self.bd.select_all()
