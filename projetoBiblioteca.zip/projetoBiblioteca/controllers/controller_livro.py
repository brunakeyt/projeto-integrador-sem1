from models.livro import Livro

from database.book_database import BookDatabase


class ControllerLivro:

    # função inicia banco de dados dos livros para gerenciar as transações.
    # função inicia a classe livro para uso das regras de negócio.
    def __init__(self):
        self.bd = BookDatabase()
        self.livro = Livro()

    # função que lista os livros do banco de dados.
    def listar_todos_livros(self):
        lista = self.bd.select_all()
        return lista

    # função que lista apenas os livros disponíveis do banco de dados.
    def listar_livros_disponiveis(self):
        lista = self.bd.select_books_available()
        return lista

    # função que adiciona livros e já insere seus respectivos ID's.
    # essa função é uma auxiliar da função de cadastrar livros que faz as validações.
    def adcionar_livro(self):
        self.livro.id_livro = int(self.bd.autoincremento())
        self.bd.insert_obj(self.livro.to_list())

    # função de busca de livros por algum dos dados do mesmo.
    def pesquisar_livro(self, tipo_pesquisa, termo_pesquisa):
        lista = []
        if tipo_pesquisa == "autor":
            lista = self.bd.find_by_author(termo_pesquisa)
        elif tipo_pesquisa == "nome":
            lista = self.bd.find_by_title(termo_pesquisa)
        elif tipo_pesquisa == "ano":
            lista = self.bd.find_by_year(termo_pesquisa)
        return lista

    # função que valida os dados do livro.
    def validar_dados_livro(self, dado, valor):
        if dado == "titulo":
            if self.livro.titulo_valido(valor):
                self.livro.titulo = valor
                return True
        elif dado == "autor":
            if self.livro.autor_valido(valor):
                self.livro.autor = valor
                return True
        elif dado == "ano_publicacao":
            if self.livro.ano_publicacao_valido(valor):
                self.livro.ano_publicacao = valor
                return True
        elif dado == "num_copias":
            if self.livro.num_copias_valido(valor):
                self.livro.num_copias = valor
                return True
        else:
            return False
