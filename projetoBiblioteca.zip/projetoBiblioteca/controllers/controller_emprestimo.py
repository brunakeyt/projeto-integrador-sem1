from database.book_database import BookDatabase
from database.lending_database import LendingDatabase
from database.user_database import UserDatabase
from models.livro import Livro
from models.usuario import Usuario


class ControllerEmprestimo:

    # função inicia banco de dados dos livros para gerenciar as transações.
    # função inicia a classe livro para uso das regras de negócio.
    # função inicia banco de dados dos usuários para gerenciar as transações.
    # função inicia a classe usuário para uso das regras de negócio.
    # função inicia banco de dados dos empréstimos para gerenciar as transações.
    # variáveis de lista para o funcionamento de outras funções.
    def __init__(self):
        self.bd_livro = BookDatabase()
        self.bd_usuario = UserDatabase()
        self.bd_emprestimo = LendingDatabase()
        self.livro = Livro()
        self.usuario = Usuario()
        self.lista_livro = []
        self.lista_emprestimo = []
        self.lista_emprestimo_id = []

    # função auxiliar de escolher_livro.
    def auxiliar_escolher_livro(self, livro_dados):
        self.livro.id_livro = livro_dados[0]
        self.livro.titulo = livro_dados[1]
        self.livro.autor = livro_dados[2]
        self.livro.ano_publicacao = livro_dados[3]
        self.livro.num_copias = livro_dados[4]

    # função que escolhe o livro na função empréstimo da viewer.
    def escolher_livro(self, id_escolhido):
        try:
            livro = self.bd_livro.find_by_id(id_escolhido)
            if int(livro[4]) == 0:
                return False
            self.auxiliar_escolher_livro(livro)
            return True
        except IndexError:
            return False

    # função que escolhe o usuário na função devolução da viewer.
    def escolher_usuario(self, escolha):
        try:
            usuario = self.bd_usuario.find_by_id(escolha)
            self.auxiliar_escolher_usuario(usuario)
            return True
        except IndexError:
            return False

    # função auxiliar de escolher_usuario.
    def auxiliar_escolher_usuario(self, usuario):
        self.usuario.id_usuario = usuario[0]
        self.usuario.nome = usuario[1]
        self.usuario.contato = usuario[2]

    # função que realiza empréstimos.
    def realizar_emprestimo(self):
        emprestimo_id = int(self.bd_emprestimo.autoincremento())
        livro_id = self.livro.id_livro
        usuario_id = self.usuario.id_usuario
        emprestimo = [str(emprestimo_id), str(livro_id), (str(usuario_id) + "\n")]
        self.bd_emprestimo.insert_obj(emprestimo)
        self.livro.emprestar()
        self.bd_livro.update_obj(livro_id, self.livro.to_list())

    # função que verifica empréstimos feitos por um usuário e retorna uma matriz.
    def verificar_emprestimo(self):
        lista_emprestimo = self.bd_emprestimo.find_by_user_id(self.usuario.id_usuario)
        if len(lista_emprestimo) == 0:
            pass
        else:
            self.lista_emprestimo = lista_emprestimo
            for emprestimo in lista_emprestimo:
                id_livro = emprestimo[1]
                id_emprestimo = emprestimo[0]
                self.lista_emprestimo_id.append(id_emprestimo)
                self.lista_livro.append(self.bd_livro.find_by_id(id_livro))
        self.lista_livro = self.lista_livro
        return self.lista_livro

    # verifica se o livro que será devolvido foi de fato emprestado.
    def verificar_livro_devolucao(self, id_livro):
        lista_livros = self.lista_livro
        for livro in lista_livros:
            if int(livro[0]) == id_livro:
                return True
        return False

    # função que devolve o livro.
    def devolver_livro(self, id_livro):
        livro_devolvido = []
        for livro in self.lista_livro:
            if int(livro[0]) == int(id_livro):
                livro_devolvido = livro
        self.livro = livro_devolvido
        emprestimo_devolucao = []
        for emprestimo in self.lista_emprestimo:
            if emprestimo[1] == self.livro[0]:
                emprestimo_devolucao = emprestimo
        self.bd_emprestimo.delete_by_id(emprestimo_devolucao[0])
        livro = Livro(self.livro[0], self.livro[1], self.livro[2], self.livro[3], self.livro[4])
        livro.devolver()
        self.bd_livro.update_obj(livro.id_livro, livro.to_list())

    # função que devolve a lista de empréstimos realizados na biblioteca.
    def listar_emprestimos_todos(self):
        lista_livros = self.bd_livro.select_all()
        lista_usuarios = self.bd_usuario.select_all()
        lista_emprestimos = self.bd_emprestimo.select_all()
        lista_view_emprestimo = []
        for emprestimo in lista_emprestimos:
            emprestimo_view = [emprestimo[0]]
            for usuario in lista_usuarios:
                if int(usuario[0]) == int(emprestimo[2]):
                    emprestimo_view.append(usuario[1])
                    break
            for livro in lista_livros:
                if livro[0] == emprestimo[1]:
                    emprestimo_view.append(livro[1])
                    break
            lista_view_emprestimo.append(emprestimo_view)
        return lista_view_emprestimo
