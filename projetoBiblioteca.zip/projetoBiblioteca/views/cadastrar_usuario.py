from controllers.controller_usuario import ControllerUsuario

usuario_controller = ControllerUsuario()

# função que recebe os dados de um usuário e faz o seu cadastro.
def cadastrar_usuario():
    print("Cadastro de Usuário")
    receber_dado_usuario("nome", "Insira o nome do novo usuário:")
    receber_dado_usuario("contato", "Insira o contato do novo Usuário:")

    usuario_controller.adcionar_usuario()

# função que recebe dados de um usuário e valida as informações.
def receber_dado_usuario(dado, msg):
    valor = input(msg)
    if usuario_controller.validar_usuario(dado, valor):
        pass
    else:
        print("valor inserido inválido")
        receber_dado_usuario(dado, msg)
