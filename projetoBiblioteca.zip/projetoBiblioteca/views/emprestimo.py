from controllers.controller_emprestimo import ControllerEmprestimo

emprestimo_controller = ControllerEmprestimo()

# função que faz o empréstimo de livros.
def emprestimo_livro():
    print("Empréstimo de Livro")
    if escolher_livro_emprestimo():
        if escolher_usuario_emprestimo():
            print("Informações sobre o empréstimo:")
            print("Livro: " + emprestimo_controller.livro.titulo + " - id:" + emprestimo_controller.livro.id_livro)
            print("Usuário: " + emprestimo_controller.usuario.nome + " - id: "
                  + emprestimo_controller.usuario.id_usuario)
            print("digite '1' se confirma o empréstimo")
            resposta = input()
            if resposta == '1':
                emprestimo_controller.realizar_emprestimo()
                print("Empréstimo confirmado! aperte enter para ir para o menu principal")
            else:
                print("escolha diferente de '1', empréstimo não confirmado,"
                      + " aperte 'enter' para ir para o menu principal")
                input("")

# função que escolhe o livro a ser emprestado.
def escolher_livro_emprestimo():
    print("Digite o id do livro que se deseja fazer o empréstimo ou digite '0' pasa sair:")
    escolha = input()
    if escolha == "0":
        return False
    else:
        if emprestimo_controller.escolher_livro(escolha):
            return True
        else:
            print("Nenhum livro disponível com esse Id, ou livro indisponível. Tente de novo")
            return escolher_livro_emprestimo()

# função que escolhe o usuário que fará o empréstimo.
def escolher_usuario_emprestimo():
    print("Digite o id do Usuario ao qual será feito o empréstimo ou digite '0' pasa sair:")
    escolha = input()
    if escolha == 0:
        return False
    else:
        if emprestimo_controller.escolher_usuario(escolha):
            return True
        else:
            print("nenhum Usuário encontrado com esse Id, tente de novo")
            return escolher_usuario_emprestimo()
