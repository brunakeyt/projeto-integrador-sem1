from controllers.controller_emprestimo import ControllerEmprestimo
from controllers.controller_livro import ControllerLivro
from controllers.controller_usuario import ControllerUsuario
from views.util import imprimir_tabela_livros, imprimir_tabela_usuarios, imprimir_tabela_emprestimos


# função que disponibiliza o menu dos relatórios possíveis.
def relatorio():
    print("página de Relatórios")
    print("Escolha uma das opções a seguir:")
    print("1- Visualizar todos os livros")
    print("2- Visualizar livros com estoque")
    print("3- Visualizar usuários cadastrados")
    print("4- Visualizar livros emprestados")
    print("5- Voltar")
    resposta = input()
    if resposta == "1":
        visualizar_todos_livros()
    elif resposta == "2":
        visualizar_livros_disponiveis()
    elif resposta == "3":
        visualizar_usuarios()
    elif resposta == "4":
        visualizar_emprestimos()
    elif resposta == "5":
        pass
    else:
        print("\nResposta inválida")
        relatorio()

# função que resulta na lista dos livros cadastrados.
def visualizar_todos_livros():
    livro_controller = ControllerLivro()
    lista = livro_controller.listar_todos_livros()
    print("Todos os Livros")
    imprimir_tabela_livros(lista)
    input("\naperte enter para sair")

# função que resulta na lista dos livros disponíveis para empréstimo.
def visualizar_livros_disponiveis():
    livro_controller = ControllerLivro()
    lista = livro_controller.listar_livros_disponiveis()
    print("Livros Disponíveis")
    imprimir_tabela_livros(lista)
    input("\naperte enter para sair")

# função que resulta na lista dos usuários da biblioteca.
def visualizar_usuarios():
    usuario_controller = ControllerUsuario()
    lista_usuario = usuario_controller.listar_todos_os_usuarios()
    print("Usuários Cadastrados")
    imprimir_tabela_usuarios(lista_usuario)
    input("\naperte enter para sair")

# função que resulta na lista dos livros emprestados e seus respectivos usuários.
def visualizar_emprestimos():
    emprestimo_controller = ControllerEmprestimo()
    lista_emprestimo = emprestimo_controller.listar_emprestimos_todos()
    print("Empréstimos Ativos")
    imprimir_tabela_emprestimos(lista_emprestimo)
    input("\naperte enter para sair")
