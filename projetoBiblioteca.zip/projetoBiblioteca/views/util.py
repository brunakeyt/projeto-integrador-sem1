# função que imprime tabelas de livros.
def imprimir_tabela_livros(lista_livros):
    print("")
    print("{:<12} | {:<40} | {:<30} | {:<10} | {:<15}".format("id do livro", "Título do Livro", "Autor", "Ano",
                                                              "Cópias Disponíveis"))
    print("-" * 120)
    for livro in lista_livros:
        id_livro = livro[0]
        nome_livro = livro[1]
        autor = livro[2]
        ano = livro[3]
        copias_disponiveis = livro[4]
        print("{:<12} | {:<40} | {:<30} | {:<10} | {:<15}".format(id_livro, nome_livro, autor, ano, copias_disponiveis))

# função que imprime tabelas de usuários.
def imprimir_tabela_usuarios(lista_usuarios):
    print("")
    print("{:<15} | {:<40} | {:<30}".format("Id do usuário", "nome do usuário", "Contato"))
    print("-" * 85)
    for usuario in lista_usuarios:
        id_usuario = usuario[0]
        nome_usuario = usuario[1]
        contato_usuario = usuario[2]
        print("{:<15} | {:<40} | {:<30}".format(id_usuario, nome_usuario, contato_usuario))

# função que imprime tabelas de empréstimos.
def imprimir_tabela_emprestimos(lista_emprestimos):
    print("")
    print("{:<15} | {:<40} | {:<30}".format("Id do empréstimo", "usuário", "Livro emprestado"))
    print("-" * 85)
    for emprestimo in lista_emprestimos:
        id_emprestimo = emprestimo[0]
        usuario_emprestimo = emprestimo[1]
        livro_emprestimo = emprestimo[2]
        print("{:<15} | {:<40} | {:<30}".format(id_emprestimo, usuario_emprestimo, livro_emprestimo))
