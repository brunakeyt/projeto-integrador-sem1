from controllers.controller_livro import ControllerLivro
from views.util import imprimir_tabela_livros

# função auxiliar da função consulta_livro
def pesquisar_livro(tipo, value):
    print("Resultado para a pesquisa:'" + value + "'")
    livro_controller = ControllerLivro()
    lista_livros = livro_controller.pesquisar_livro(tipo, value)
    imprimir_tabela_livros(lista_livros)
    input("\naperte enter para sair")

# função que faz as consultas a partir de algum dado do livro.
def consulta_livros():
    print("Consulta de Livros:")
    print("Escolha uma das opções a seguir:")
    print("1- pesquisar por título")
    print("2- pesquisar por autor(a)")
    print("3- pesquisar por ano de publicação")
    print("4- Voltar")
    resposta = input()
    if resposta == "1":
        res_pesquisa = input("Digite o título do livro que você deseja achar:")
        pesquisar_livro("nome", res_pesquisa)
    elif resposta == "2":
        res_pesquisa = input("Digite o nome do autor(a) que você deseja achar:")
        pesquisar_livro("autor", res_pesquisa)
    elif resposta == "3":
        res_pesquisa = input("Digite o nome do autor(a) que você deseja achar:")
        pesquisar_livro("ano", res_pesquisa)
    elif resposta == "4":
        pass
    else:
        print("\nResposta inválida")
        consulta_livros()
