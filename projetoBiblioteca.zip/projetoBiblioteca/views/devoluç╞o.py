from controllers.controller_emprestimo import ControllerEmprestimo
from views.util import imprimir_tabela_livros

emprestimo_controller = ControllerEmprestimo()

# função que mostra os livros para devolução, e depois usa outra função para de fato devolver o livro.
def devolucao_livro():
    print("Empréstimo de Livro")
    if escolher_usuario_devolucao():
        lista_livros = emprestimo_controller.verificar_emprestimo()
        usuario_nome = emprestimo_controller.usuario.nome
        if len(lista_livros) == 0:
            print("nenhum empréstimo de livro encontrado para o/a usuário: " + usuario_nome)
        else:
            print("Livros encontrados para o/a usuário: " + usuario_nome)
            imprimir_tabela_livros(lista_livros)
            devolver_livro()

# função que devolve o livro.
def devolver_livro():
    print("Digite o id do livro que se deseja devolver:")
    id_livro = input()
    if id_livro.isnumeric():
        if emprestimo_controller.verificar_livro_devolucao(int(id_livro)):
            emprestimo_controller.devolver_livro(id_livro)
    else:
        print("tente novamente, digite um valor númerico")
        devolucao_livro()

# função que identifica o usuário para o qual será feita a devolução.
def escolher_usuario_devolucao():
    print("Digite o id do Usuario ao qual se deseja fazer a devolução ou digite '0' pasa sair:")
    escolha = input()
    if escolha == 0:
        return False
    else:
        if emprestimo_controller.escolher_usuario(escolha):
            return True
        else:
            print("nenhum Usuário encontrado com esse Id, tente de novo")
            return escolher_usuario_devolucao()
