from controllers.controller_livro import ControllerLivro

livro_controller = ControllerLivro()

# função que recebe os dados do livro e depois cadastra o livro.
def cadastrar_livro():
    print("Cadastro de Livro")
    receber_dado_livro("titulo", "Digite o título do livro:")
    receber_dado_livro("autor", "Digite o nome do Autor(a) do livro:")
    receber_dado_livro("ano_publicacao", "Digite o ano de lançamento do livro:")
    receber_dado_livro("num_copias", "digite o núemro de cópias disponíveis do livro:")

    livro_controller.adcionar_livro()

# função que valida os dados recebidos dos livros.
def receber_dado_livro(dado, msg):
    valor = input(msg)
    if livro_controller.validar_dados_livro(dado, valor):
        return valor
    else:
        print("valor inserido inválido")
        return receber_dado_livro(dado, msg)
