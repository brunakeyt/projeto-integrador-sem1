from views.cadastrar_usuario import cadastrar_usuario
from views.devolução import devolucao_livro
from views.emprestimo import emprestimo_livro
from views.relatorio import relatorio
from views.consulta_livros import consulta_livros
from views.cadastrar_livro import cadastrar_livro

print("-Sistema de Gerenciamento da Biblioteca-")
while True:
    print("\nEscolha uma opção a seguir:")
    print("1- Cadastrar Livros")
    print("2- Cadastrar Usuário")
    print("3- Empréstimo de Livros")
    print("4- Devolução de Livros")
    print("5- Consulta de Livros")
    print("6- Relatórios")
    print("7-Sair")
    resposta = input()
    if resposta == "7":
        print("Obrigado por usar o Sistema de Gerenciamento da Biblioteca")
        break
    elif resposta == "1":
        cadastrar_livro()
    elif resposta == "2":
        cadastrar_usuario()
    elif resposta == "3":
        emprestimo_livro()
    elif resposta == "4":
        devolucao_livro()
    elif resposta == "5":
        consulta_livros()
    elif resposta == "6":
        relatorio()
    else:
        print("resposta Inválida!")
