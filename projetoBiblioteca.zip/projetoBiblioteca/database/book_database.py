from database.database import Database


# classe de livros
class BookDatabase(Database):

    # inicia a classe e conecta com o arquivo livros
    def __init__(self):
        super().__init__("livros")

    # acha livro pelo nome.
    # retorna uma matriz com dados dos livros.
    def find_by_title(self, value):
        return self.search_by_column(1, value)

    # acha livro pelo autor.
    # retorna uma matriz com os livros do autor.
    def find_by_author(self, value):
        return self.search_by_column(2, value)

    # acha livro pelo ano.
    # retorna uma matriz com os livros do ano selecionado.
    def find_by_year(self, value):
        return self.search_by_column(3, value)

    # retorna uma matriz com os livros disponíveis para empréstimo.
    def select_books_available(self):
        lista_itens = self.select_all()
        results = []
        for item in lista_itens:
            if item[4] != "0\n":
                results.append(item)
        return results
