# transforma strings em listas
def ler_dados(lista_dados):
    nova_lista = []
    for dados in lista_dados:
        dados = dados.split(";")
        nova_lista.append(dados)
    return nova_lista

# transforma uma matriz em strings
def escrever_dados(lista_dados):
    nova_lista = []
    for dados in lista_dados:
        string_dados = ""
        for i in range(len(dados)):
            if i == len(dados) - 1:
                string_dados += str(dados[i])
            else:
                string_dados += str(dados[i]) + ";"
        nova_lista.append(string_dados)
    return nova_lista

# transforma uma lista em strings
def escrever_dado(obj):
    string_dados = ""
    for i in range(len(obj)):
        if i == len(obj) - 1:
            string_dados += str(obj[i])
        else:
            string_dados += str(obj[i]) + ";"
    return string_dados
