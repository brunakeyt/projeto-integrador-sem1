from database.database import Database


# classe de empréstimos
class LendingDatabase(Database):

    # inicia a classe e conecta com o arquivo emprestimos
    def __init__(self):
        super().__init__("emprestimos")

    # encontra os empréstimos feitos por um usuário específico.
    # retorna uma matriz.
    def find_by_user_id(self, id_pessoa):
        return self.search_by_column(2, id_pessoa)
