from database.database import Database

# essa classe usa as funções herdadas da classe mãe, não há funções específicas apenas dessa tabela.
class UserDatabase(Database):

    def __init__(self):
        super().__init__("usuario")
