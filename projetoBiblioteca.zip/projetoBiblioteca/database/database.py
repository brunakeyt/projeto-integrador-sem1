from database.util import ler_dados, escrever_dados, escrever_dado


# classe que gerencia as transações do banco de dados.
class Database:
    # verifica se um banco de dados existe, e caso ele não exista, cria um novo.
    # o parâmetro banco define o nome do banco de dados/arquivo.
    def __init__(self, banco):
        self.banco = banco + ".txt"
        try:
            with open(self.banco, "r") as file:
                pass
        except FileNotFoundError:
            with open(self.banco, "w") as file:
                pass

    # retorna uma lista com todos os itens do banco de dados que usar a função.
    def select_all(self):
        with open(self.banco, "r") as file:
            return ler_dados(file.readlines())

    # retorna uma lista com os dados de um item a partir de um ID.
    def find_by_id(self, id_obj):
        matriz = self.search_by_column(0, id_obj)
        return matriz[0]

    # a partir da posição de uma coluna busca-se um elemento que pode estar presente uma ou diversas colunas.
    # o resultado é uma matriz com todos os itens compatíveis com o valor buscado em qualquer parte do campo.
    # é uma função auxiliar de outras funções.
    def search_by_column(self, column, value):
        lista_itens = self.select_all()
        results = []
        for item in lista_itens:
            if item[column].lower().find(str(value).lower()) != -1:
                results.append(item)
        return results

    # função de reescrita do arquivo, reescreve com as mudanças que precisam ser feita.
    # # É apenas uma função auxiliar de delete e update.
    def insert_all(self, list_new_itens):
        with open(self.banco, "w") as file:
            for new_item in list_new_itens:
                file.write(new_item)

    # adiciona um item ao arquivo.
    def insert_obj(self, obj):
        with open(self.banco, "a") as file:
            file.write(escrever_dado(obj))

    # modifica um item de acordo com o ID.
    def update_obj(self, id_obj, obj):
        list_itens = self.select_all()
        index = 0
        for i in range(len(list_itens)):
            if list_itens[i][0].find(str(id_obj)) != -1:
                index = i
                break
        list_itens[index] = obj
        self.insert_all(escrever_dados(list_itens))

    # deleta um item de acordo com o ID.
    def delete_by_id(self, id_obj):
        list_itens = self.select_all()
        list_new_itens = []
        for livro in list_itens:
            if livro[0].find(str(id_obj)) == -1:
                list_new_itens.append(livro)
        self.insert_all(escrever_dados(list_new_itens))

    # identifica qual o último ID usado no arquivo para fazer o autoincremento.
    def autoincremento(self):
        list_itens = self.select_all()
        try:
            last_item = list_itens[-1]
            return int(last_item[0]) + 1
        except IndexError as e:
            return 1
