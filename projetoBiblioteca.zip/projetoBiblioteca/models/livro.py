class Livro:

    # função que define as variáveis do objeto e instância ao objeto.
    def __init__(self, id_livro=0, titulo="", autor="", ano_publicacao=0, num_copias=0):
        self.id_livro = id_livro
        self.titulo = titulo
        self.autor = autor
        self.ano_publicacao = ano_publicacao
        self.num_copias = num_copias

    # função que transforma os dados do objeto em uma lista.
    def to_list(self):
        livro = [str(self.id_livro), str(self.titulo), str(self.autor), str(self.ano_publicacao),
                 str(self.num_copias) + "\n"]
        return livro

    # função que determina se um título é válido
    @staticmethod
    def titulo_valido(titulo):
        if titulo.strip() != "":
            return True
        return False

    # função que determina se um autor é válido
    @staticmethod
    def autor_valido(autor):
        if autor.strip() != "":
            return True
        return False

    # função que determina se um ano é válido
    @staticmethod
    def ano_publicacao_valido(ano):
        if str(ano).isnumeric():
            if (int(ano) > 1800) and (int(ano) < 2100):
                return True
        return False

    # função que determina se o número de cópias é válido
    @staticmethod
    def num_copias_valido(num):
        if str(num).isnumeric():
            if int(num) > 0:
                return True
        return False

    #função que determina que ao emprestar um livro, o estoque diminui.
    def emprestar(self):
        self.num_copias = int(self.num_copias) - 1

    #função que determina que ao devolver um livro, o estoque aumenta.
    def devolver(self):
        self.num_copias = int(self.num_copias) + 1
