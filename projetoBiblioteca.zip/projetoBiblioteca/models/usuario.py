class Usuario:

    # função que define as variáveis do objeto.
    def __init__(self, id_usuario="0", nome="", contato=""):
        self.id_usuario = id_usuario
        self.nome = nome
        self.contato = contato

    # função que transforma os dados do objeto em uma lista.
    def to_list(self):
        usuario = [str(self.id_usuario),self.nome, str(self.contato) + "\n"]
        return usuario

    # função que define se um nome é válido.
    @staticmethod
    def nome_valido(nome):
        if nome.strip() != "":
            return True
        return False

    # função que define se um contato é válido.
    @staticmethod
    def contato_valido(contato):
        if contato.strip() != "":
            return True
        return False